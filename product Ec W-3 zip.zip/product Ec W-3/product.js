<script>
  let cart = [];

  function addToCart() {
    // You can customize this function to add the selected product to the cart
    cart.push("Product Name");
    updateCartDisplay();
  }

  function updateCartDisplay() {
    const cartItemsContainer = document.getElementById("cart-items");
    cartItemsContainer.innerHTML = "";

    cart.forEach(item => {
      const cartItemDiv = document.createElement("div");
      cartItemDiv.classList.add("cart-item");
      cartItemDiv.textContent = item;
      cartItemsContainer.appendChild(cartItemDiv);
    });
  }

  function viewCart() {
    alert("Cart Contents: " + cart.join(", "));
  }
</script>